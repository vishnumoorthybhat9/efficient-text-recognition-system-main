OCR training dataset - labels.csv columns: file,text,kind,font,split

handwritten/  IAM handwriting database lines (Teklia/IAM-line, MIT licence),
              40 px high. split=train is the official train+test sets,
              split=val is the official validation set (held out).
printed/      one rendered word per image, 48 px high, 1 bit. Words with the
              same font id share a baseline and are joined into lines by
              the trainer.

Add your own data: drop images in a new folder and append rows to labels.csv
(kind=handwritten for whole line images, font empty, split=train or val).
